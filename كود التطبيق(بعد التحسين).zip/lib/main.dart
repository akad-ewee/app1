import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(FitnessApp());
}

class FitnessApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: Color(0xFF047A48),
        appBarTheme: const AppBarTheme(
          backgroundColor:Color(0xFF047A48),
          titleTextStyle: TextStyle(color: Color(0xFFD4AF37), fontSize: 20),
        ),
      ),
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      duration: const Duration(seconds: 7),
      vsync: this,
    )..forward();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(_controller);

    Future.delayed(const Duration(seconds: 7), () {
      Navigator.pushReplacement(
        context,
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => MyApp(),
          transitionsBuilder: (_, animation, __, child) {
            return FadeTransition(opacity: animation, child: child);
          },
        ),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF047A48),
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.paid, size: 100, color: Color(0xFFD4AF37)),
              const SizedBox(height: 20),
              const Text(
                "  Vireo  مرحبا بكم في ",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold,fontFamily:'Pacifico',color: Color(0xFFD4AF37)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool isLightMode = false; // المتغير الذي يخزن حالة الوضع

  void toggleTheme() {
    setState(() {
      isLightMode = !isLightMode; // التبديل بين الوضعين
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: isLightMode
          ? ThemeData.light().copyWith(
              primaryColor: Color(0xFF047A48),
              scaffoldBackgroundColor: Colors.white,
              appBarTheme: AppBarTheme(backgroundColor:Color(0xFF047A48)),
              textTheme: TextTheme(bodyText2: TextStyle(color: Colors.black)),
            )
          : ThemeData.dark().copyWith(
              primaryColor: Color(0xFF0D1B2A),
              scaffoldBackgroundColor: Color(0xFF0D1B2A),
              appBarTheme: AppBarTheme(backgroundColor: Color(0xFF0E2C24)),
              textTheme: TextTheme(bodyText2: TextStyle(color: Colors.white)),
            ),
      initialRoute: '/',
      routes: {
        '/': (context) => VideoScreen(isLightMode: isLightMode, toggleTheme: toggleTheme),
        '/questions': (context) => QuestionsPage(isLightMode: isLightMode),
        '/settings': (context) => SettingsPage(isLightMode: isLightMode, toggleTheme: toggleTheme),
      },
    );
  }
}

class VideoScreen extends StatefulWidget {
  final bool isLightMode;
  final Function toggleTheme;

  VideoScreen({required this.isLightMode, required this.toggleTheme});

  @override
  _VideoScreenState createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  late YoutubePlayerController _controller;

  @override
  void initState() {
    super.initState();
    _controller = YoutubePlayerController(
      initialVideoId: YoutubePlayer.convertUrlToId('https://youtu.be/TZV0RZIowHs')!,
      flags: YoutubePlayerFlags(
        autoPlay: true,
        loop: true,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.isLightMode ? Colors.white : Color(0xFF0D1B2A),
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar('Vireo'),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Center(
                child: Text(
                  'الاستدامة الاقتصادية\nتعني تحقيق نمو اقتصادي مستمر دون استنزاف الموارد الطبيعية أو الإضرار بالمجتمع. 🌍✨ تهدف إلى التوازن بين الربح، البيئة، والعدالة الاجتماعية لضمان ازدهار الأجيال الحالية والمستقبلية. 🌱',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 17,
                    color: widget.isLightMode ? Colors.black : Colors.white,
                  ),
                ),
              ),
            ),
            Expanded(
              child: YoutubePlayer(
                controller: _controller,
                showVideoProgressIndicator: true,
                progressIndicatorColor: Colors.amber,
              ),
            ),
            _buildBottomNavigationBar(context),
          ],
        ),
      ),
    );
  }

  Widget _buildAppBar(String title) {
    return Container(
      padding: EdgeInsets.all(16.0),
      color: widget.isLightMode ? Color(0xFF047A48) : Color(0xFF0E2C24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: Icon(Icons.settings, color: Color(0xFFD4AF37)),
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
          Text(
            title,
            style: TextStyle(
              fontFamily: 'Pacifico',
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFFD4AF37),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigationBar(BuildContext context) {
    return Container(
      color: widget.isLightMode ? Color(0xFF047A48) : Color(0xFF0E2C24),
      padding: EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
            icon: Icon(Icons.home, color: Color(0xFFD4AF37)),
            onPressed: () {
              Navigator.pushNamed(context, '/');
            },
          ),
          IconButton(
            icon: Icon(Icons.attach_file, color: Color(0xFFD4AF37)),
            onPressed: () {
              Navigator.pushNamed(context, '/questions');
            },
          ),
        ],
      ),
    );
  }
}

class QuestionsPage extends StatefulWidget {
  final bool isLightMode;

  QuestionsPage({required this.isLightMode});

  @override
  _QuestionsPageState createState() => _QuestionsPageState();
}

class _QuestionsPageState extends State<QuestionsPage> {
  final List<Map<String, dynamic>> questions = [
    {
      'question': 'ما هي الاستدامة الاقتصادية؟',
      'options': ['تحقيق نمو مستمر', 'تقليل التلوث', 'زيادة الضرائب', 'استنزاف الموارد'],
      'correctIndex': 0,
    },
    {
      'question': 'ما هو الهدف الرئيسي للاستدامة الاقتصادية؟',
      'options': ['زيادة الأرباح', 'حماية البيئة', 'تحقيق العدالة الاجتماعية', 'التوازن بين الربح والبيئة'],
      'correctIndex': 3,
    },
    {
      'question': 'أي من هذه العوامل تدعم الاستدامة الاقتصادية؟',
      'options': ['الاستثمار في الطاقة النظيفة', 'الاعتماد على الفحم', 'إزالة الغابات', 'الصيد الجائر'],
      'correctIndex': 0,
    },
    {
      'question': 'ما هي مصادر الطاقة المستدامة؟',
      'options': ['الطاقة الشمسية', 'النفط', 'الفحم', 'الغاز الطبيعي'],
      'correctIndex': 0,
    },
    {
      'question': 'ما هو مفهوم الاقتصاد الدائري؟',
      'options': ['إعادة التدوير', 'زيادة الاستهلاك', 'التخلص من النفايات', 'التلوث الصناعي'],
      'correctIndex': 0,
    },
    {
      'question': 'أي من هذه الأنشطة يعتبر مستدامًا؟',
      'options': ['الزراعة العضوية', 'قطع الأشجار الجائر', 'حرق النفايات', 'الصيد الجائر'],
      'correctIndex': 0,
    },
    {
      'question': 'ما هو تأثير الاستدامة الاقتصادية على المجتمع؟',
      'options': ['زيادة فرص العمل', 'زيادة التلوث', 'تقليل الرواتب', 'استنزاف الموارد'],
      'correctIndex': 0,
    },
    {
      'question': 'كيف يمكن دعم الاستدامة الاقتصادية؟',
      'options': ['دعم الشركات الصديقة للبيئة', 'تشجيع الاستهلاك المفرط', 'استخدام الفحم', 'إهمال تدوير النفايات'],
      'correctIndex': 0,
    },
    {
      'question': 'ما هو التحدي الأكبر للاستدامة الاقتصادية؟',
      'options': ['التغير المناخي', 'زيادة الاستثمار', 'رفع الضرائب', 'التلوث الضوضائي'],
      'correctIndex': 0,
    },
    {
      'question': 'أي من هذه الدول تعتبر رائدة في الاستدامة؟',
      'options': ['السويد', 'الصين', 'الولايات المتحدة', 'الهند'],
      'correctIndex': 0,
    },
  ];

  final Map<int, int?> selectedAnswers = {};
  final AudioPlayer player = AudioPlayer();

  void playSound(String soundFile) async {
    await player.play(AssetSource('assets/sounds/$soundFile'));
  }

  void checkResult() {
    int correctAnswers = selectedAnswers.entries
        .where((entry) => entry.value == questions[entry.key]['correctIndex'])
        .length;

    String message = '';
    String soundFile = '';

    if (correctAnswers == 10) {
      message = 'ممتاز! أحسنت! 🎉';
      soundFile = '';
    } else if (correctAnswers >= 7) {
      message = 'جيد جدًا! استمر 💪';
      soundFile = '';
    } else if (correctAnswers >= 4) {
      message = 'مقبول، حاول التحسن 😊';
      soundFile = '';
    } else {
      message = 'أداء ضعيف، حاول مرة أخرى 😟';
      soundFile = 'audio1.wav';
    }

    playSound(soundFile);

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('نتيجتك'),
        content: Text('$message\nإجاباتك الصحيحة: $correctAnswers من ${questions.length}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('حسنًا'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: widget.isLightMode ? Colors.white : Color(0xFF0D1B2A),
      body: SafeArea(
        child: Column(
          children: [
            _buildAppBar('Vireo'),
            Expanded(
              child: ListView.builder(
                itemCount: questions.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(questions[index]['question'], style: TextStyle(color: widget.isLightMode ? Colors.black : Colors.white)),
                    subtitle: Column(
                      children: List.generate(4, (i) {
                        return RadioListTile<int>(
                          value: i,
                          groupValue: selectedAnswers[index],
                          onChanged: (value) {
                            setState(() {
                              selectedAnswers[index] = value;
                            });
                          },
                          title: Text(questions[index]['options'][i], style: TextStyle(color: widget.isLightMode ? Colors.black : Colors.white)),
                        );
                      }),
                    ),
                  );
                },
              ),
            ),
            _buildBottomNavigationBar(context),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: widget.isLightMode ? Color(0xFF047A48)
 : Color(0xFFD4AF37),
        onPressed: checkResult,
        child: Icon(Icons.send, color: widget.isLightMode ? Colors.black : Colors.white),
      ),
    );
  }

  Widget _buildAppBar(String title) {
    return Container(
      padding: EdgeInsets.all(16.0),
      color: widget.isLightMode ? Color(0xFF047A48)
 : Color(0xFF0E2C24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          IconButton(
            icon: Icon(Icons.settings, color: Color(0xFFD4AF37)),
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
          Text(
            title,
            style: TextStyle(
              fontFamily: 'Pacifico',
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFFD4AF37),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomNavigationBar(BuildContext context) {
    return Container(
      color: widget.isLightMode ? Color(0xFF047A48)
 : Color(0xFF0E2C24),
      padding: EdgeInsets.symmetric(vertical: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          IconButton(
            icon: Icon(Icons.home, color: Color(0xFFD4AF37)),
            onPressed: () {
              Navigator.pushNamed(context, '/');
            },
          ),
          IconButton(
            icon: Icon(Icons.attach_file, color: Color(0xFFD4AF37)),
            onPressed: () {
              Navigator.pushNamed(context, '/questions');
            },
          ),
        ],
      ),
    );
  }
}

class SettingsPage extends StatelessWidget {
  final bool isLightMode;
  final Function toggleTheme;

  SettingsPage({required this.isLightMode, required this.toggleTheme});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: isLightMode ? Colors.white : Color(0xFF0D1B2A),
      appBar: AppBar(
        title: Text('الإعدادات'),
        backgroundColor: isLightMode ? Color(0xFF047A48)
 : Color(0xFF0E2C24),
        actions: [
          IconButton(
            icon: Icon(Icons.settings, color: Color(0xFFD4AF37)),
            onPressed: () {
              Navigator.pushNamed(context, '/settings');
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            ListTile(
              leading: Icon(Icons.phone, color: Color(0xFFD4AF37)),
              title: Text('اتصل بنا', style: TextStyle(color: isLightMode ? Colors.black : Colors.white)),
              onTap: () async {
                const url = '+962798905480'; 
                if (await canLaunch(url)) {
                  await launch(url);
                } else {
                  throw 'Could not launch $url';
                }
              },
            ),
            ListTile(
              leading: Icon(Icons.wb_sunny, color: Color(0xFFD4AF37)),
              title: Text('الوضع الفاتح', style: TextStyle(color: isLightMode ? Colors.black : Colors.white)),
              onTap: () {
                toggleTheme();
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}